#!/bin/bash
server_ip=$(cat /root/serverIp.txt)
if [ ! -n "$server_ip" ];then
    echo "no server ip"
    exit 1
fi
getIp_url="http://""$server_ip"":2333/getIpAddress"
saveIp_url="http://""$server_ip"":2333/saveIpAddress"
exec_url="http://""$server_ip"":2333/files/main"
Platform=`uname -a| grep Ubuntu`
Netcard=`ls /sys/class/net | grep -E 'en|eth' | grep -v -E '^lo|v'|awk '{print $1}'`
sed -i "/miner.forke/d" /etc/hosts
addstr="$server_ip""  miner.forke.cn"
sed -i '1i\'"$addstr" /etc/hosts
if [ -n "$Platform" ];then
	if ! command -v ifconfig > /dev/null;then
		apt update -y
		apt install net-tools -y
	fi
	line_num=`grep -rn "iface" /etc/network/interfaces |grep loopback|sed -n '1p'|awk -F":" '{print $1}'`
	line_num=`expr "$line_num" + 1`
	echo $line_num
	p=/etc/network/interfaces
	nowIp=`ifconfig "$Netcard" | grep inet| grep -v inet6| awk '{print $2}'`
	str=$(echo $nowIp | grep :)
	if [ "$str" != "" ];then
		nowIp=`echo "$nowIp"|awk -F: '{print $2}'`
	fi
	getip=`curl -d ipAddr="$nowIp" $getIp_url`
	gate=${nowIp%.*}".1"
	echo $getip
	sed -i "$line_num"',$d' "$p"
	echo auto "$Netcard" >> "$p"
	echo iface "$Netcard" inet static >> "$p"
	echo address "$getip" >> "$p"
	echo "netmask 255.255.255.0" >> "$p"
	echo gateway "$gate" >> "$p"

	sed -i '/nameserver/d' /etc/resolvconf/resolv.conf.d/head
	echo "nameserver 8.8.8.8" >> /etc/resolvconf/resolv.conf.d/head
	
	curl -d ipAddr="$getip" "$saveIp_url"
	if ! command -v wget > /dev/null;then
		apt update -y
		apt install wget -y
	fi
	rm -rf /root/main
	wget -P /root/ "$exec_url"
	chmod +x /root/main
	echo "download monitor"
	cd /etc/init.d
	rm -rf forke_start.sh
	touch forke_start.sh
	echo "forke_start" >> forke_start.sh
    sed -i '1i\#!/bin/bash' forke_start.sh
	echo "nohup /root/main &" >> forke_start.sh
	echo "exit 0" >> forke_start.sh
	sed -i "/forke_start/d" forke_start.sh
	chmod +x forke_start.sh
    update-rc.d forke_start.sh defaults 90
    echo "set complete"
	reboot
else
	if ! command -v ifconfig > /dev/null;then
		yum install net-tools.x86_64 -y
		echo "download nettools"
	fi
	p=/etc/sysconfig/network-scripts/ifcfg-"$Netcard"
	sed -i '/^BOOTPROTO/d' "$p"
	sed -i '/^IPADDR/d' "$p"
	sed -i '/^NETMASK/d' "$p"
	sed -i '/^GATEWAY/d' "$p"
	sed -i '/^DNS1/d' "$p"
	nowIp=`ifconfig "$Netcard" | grep inet| grep -v inet6| awk '{print $2}'`
	getip=`curl -d ipAddr="$nowIp" $getIp_url`
	if [ ! -n "$getip" ];then
	    echo "get Ip error"
	    exit 1
	fi
	gate=${nowIp%.*}".1"
	echo $nowIp
	echo $getip
	echo BOOTPROTO=static >> "$p"
	echo IPADDR="$getip" >> "$p"
	echo NETMASK=255.255.255.0 >> "$p"
	echo GATEWAY="$gate" >> "$p"
	echo DNS1=8.8.8.8 >> "$p"
    if ! command -v wget > /dev/null;then
		yum install wget -y
		echo "download network"
	fi

	curl -d ipAddr="$getip" "$saveIp_url"

	rm -rf /root/main
	wget -P /root/ "$exec_url"
	echo "download monitor"
	chmod +x /root/main
	systemctl stop firewalld
	sed -i "/\/root\/main/d" /etc/rc.d/rc.local
	echo "nohup /root/main &" >> /etc/rc.d/rc.local
	chmod +x /etc/rc.d/rc.local
	echo "set complete"
	reboot
fi