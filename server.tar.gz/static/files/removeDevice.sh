#!/bin/bash
Platform=`uname -a| grep Ubuntu`
Netcard=`ifconfig | grep -B 1 ${server_ip%.*}| awk 'NR==1 {print $1}'|awk -F: '{print $1}'`
Pro_path="/root/main"
rm -rf "$Pro_path"
kill -9 $(pidof /home/main)
if [ -n "$Platform" ];then
    line_num=`grep -rn "iface" /etc/network/interfaces |grep loopback|sed -n '1p'|awk -F":" '{print $1}'`
	line_num=`expr "$line_num" + 1`
	p=/etc/network/interfaces
	sed -i "$line_num"',$d' "$p"
	cd /etc/init.d
    update-rc.d -f forke_start.sh remove
    rm -rf forke_start.sh
	reboot
else
	p=/etc/sysconfig/network-scripts/ifcfg-"$Netcard"
    sed -i '/^BOOTPROTO/d' "$p"
	sed -i '/^IPADDR/d' "$p"
	sed -i '/^NETMASK/d' "$p"
	sed -i '/^GATEWAY/d' "$p"
	sed -i '/^DNS1/d' "$p"
	echo "BOOTPROTO=DHCP" >> "$p"
	sed -i "/^\/root\/main/d" /etc/rc.d/rc.local
	sed -i "/miner.forke/d" /etc/hosts
	kill -9 $(pidof /root/main)
	service network restart
fi
