window.leftObj = window.leftObj || {};

$(function () {
    var userId = sessionStorage.getItem("id");
    if (!userId) {
        return window.location.href = "/";
    }
    $("#login_username").html(sessionStorage.getItem("user_name"));
    leftObj.init();

    // 设置左边 选中（参数 需要从 路由中传递）
    var panelObj = $('.panel').eq(level1);
    $('.panel,.triangle,.collapse-item li').removeClass('active');
    panelObj.addClass('active');
    panelObj.find('.collapse').addClass('in');
    panelObj.find('.collapse-item li').eq(level2).addClass('active');
    panelObj.find('.triangle').addClass('active');

});

leftObj = {
    init: function () {
        $('.collapse').collapse('hide');
        $('.collapse').eq(level1).collapse();
        this.bindEvent();
    },
    bindEvent: function () {
        var that = this;

        $('.login-out').on('click', function () {
            layer.confirm('确定退出吗？', function () {
                sessionStorage.removeItem('user_name');
                sessionStorage.removeItem('id');
                window.location.href = '/';
            });
        });

        $('.navigation').on('click', function () {
            $(this).find('span.red-circle').removeClass('red-circle').addClass('circle');
            that.getNotices();
        });

        $('.user-avatar').hover(function () {
            var _self = this;
            that.tips = layer.tips($(_self).next('h3').html(), _self, {tips: 4});
        }, function () {
            layer.close(that.tips);
        });

        $('#accordion .panel').on('click', function () {
            $('.panel,.triangle').removeClass('active');
            $(this).addClass('active').find('.triangle').addClass('active');

        });
    }
};