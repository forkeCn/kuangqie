var util = {
    isPrint: false,
    runFlag: 'runUId',
    log: function (msg) {
        if (this.isPrint) {
            console.log(msg);
        }
    },
    alert: function (msg) {
        layer.alert(msg);
    },
    confirm: function (msg, okFn, cancelFn) {
        layer.confirm(msg, {
            btn: ['确定', '取消'] //按钮
        }, function () {
            okFn && okFn();
        }, function () {
            cancelFn && cancelFn();
        });
    },
    showImg: function () {
        var that = this;
        $(document).on('click', '.links', function (event) {
            event = event || window.event;
            var target = event.target || event.srcElement,
                link = target.src ? target.parentNode : target,
                options = {index: link, event: event},
                links = this.getElementsByTagName('a');
            blueimp.Gallery(links, options);
        })

    },
    getYearWeek: function (a, b, c) {
        //date1是当前日期
        //date2是当年第一天
        //d是当前日期是今年第多少天
        //用d + 当前年的第一天的周差距的和在除以7就是本年第几周
        var date1 = new Date(a, parseInt(b) - 1, c),
            date2 = new Date(a, 0, 1),
            d = Math.round((date1.valueOf() - date2.valueOf()) / 86400000);
        return Math.ceil((d + ((date2.getDay() + 1) - 1)) / 7);
    },
    dateFormat: function (date, fmt) {
        var o = {
            "M+": date.getMonth() + 1, //月份
            "d+": date.getDate(), //日
            "h+": date.getHours(), //小时
            "m+": date.getMinutes(), //分
            "s+": date.getSeconds(), //秒
            "q+": Math.floor((date.getMonth() + 3) / 3), //季度
            "S": date.getMilliseconds() //毫秒
        };
        if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
        for (var k in o)
            if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
        return fmt;
    },
    getWeeks: function (num = 7) {
        if (num <= 0) {
            num = 7;
        }

        var arr = [],
            now = new Date(),
            fmt = 'yyyy-MM-dd';

        var currentDay = now.getDay();
        if (currentDay == 0) {
            currentDay = 7
        }

        var mondayTime = now.getTime() - (currentDay - 1) * 24 * 60 * 60 * 1000;
        var curDate = new Date(mondayTime);
        var yearWeek = this.getYearWeek(curDate.getFullYear(), curDate.getMonth() + 1, curDate.getDate());
        arr.push({
            'days': this.dateFormat(new Date(mondayTime), fmt),
            'num': yearWeek
        });
        num = num - 1;
        for (var i = 0; i < num; i++) {
            mondayTime = mondayTime - 7 * 24 * 60 * 60 * 1000;
            curDate = new Date(mondayTime);
            yearWeek = this.getYearWeek(curDate.getFullYear(), curDate.getMonth() + 1, curDate.getDate());
            arr.push({
                'days': this.dateFormat(new Date(mondayTime), fmt),
                'num': yearWeek
            });
        }

        return arr;
    },
    //生成从minNum到maxNum的随机数
    randomNum: function (minNum, maxNum) {
        switch (arguments.length) {
            case 1:
                return parseInt(Math.random() * minNum + 1, 10);
                break;
            case 2:
                return parseInt(Math.random() * (maxNum - minNum + 1) + minNum, 10);
                break;
            default:
                return 0;
                break;
        }
    },
    getRecentMons: function (num) {
        //创建现在的时间
        var data = new Date();
        //获取年
        var year = data.getFullYear();
        //获取月
        var mon = data.getMonth() + 1 + 1;
        var arry = new Array();
        for (var i = 0; i < num; i++) {
            mon = mon - 1;
            if (mon <= 0) {
                year = year - 1;
                mon = mon + 12;
            }
            if (mon < 10) {
                mon = "0" + mon;
            }

            arry[i] = year + "-" + mon;
        }

        return arry;
    },

    ajax: function (url, data, successback, errorback, arg, type) {
        var that = this;
        $.ajax({
            url: url,
            type: type == undefined ? "POST" : "GET",
            cache: false,
            data: data,
            success: function (res) {
                that.log(url);
                that.log(res);
                if (!arg) {
                    successback && successback(res);
                } else {
                    successback && successback(res, arg);
                }
            },
            error: function (err) {
                that.log(err);
                if (!arg) {
                    errorback && errorback(err);
                } else {
                    errorback && errorback(err, arg);
                }
            }
        });
    },
    QueryString: function (item) {
        var svalue = location.search.match(new RegExp("[\?\&]" + item + "=([^\&]*)(\&?)", "i"));
        return svalue ? svalue[1] : svalue;
    },
    QueryStringParam: function (item) {
        var svalue = location.search.match(new RegExp("[\&]" + item + "=([^\&]*)(\&?)", "i"));
        return svalue ? svalue[1] : svalue;
    },
    //替换url参数值
    changeUrlArg: function (url, arg, val) {
        var pattern = arg + '=([^&]*)';
        var replaceText = arg + '=' + val;
        return url.match(pattern) ? url.replace(eval('/(' + arg + '=)([^&]*)/gi'), replaceText) : (url.match('[\?]') ? url + '&' + replaceText : url + '?' + replaceText);
    },
    //手机号码
    checkMobile: function (str) {
        return str.match(/^1[0-9]{10}$/i);
    },
    checkEmail: function (str) {
        var reg = /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(.[a-zA-Z0-9_-])+/;
        return reg.test(str);
    },
    GetRequest: function (url) {
        var theRequest = {};
        var str = "";
        if (url.indexOf("?") != -1) {
            str = url.substr(1);
        } else {
            str = url;
        }
        var strs = str.split("&");
        for (var i = 0; i < strs.length; i++) {
            theRequest[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);
        }
        return theRequest;
    },
    compare: function (property) {
        return function (a, b) {
            var value1 = a[property];
            var value2 = b[property];
            return value1 - value2;
        }
    },
    drawLineChart: function (id, data, chart, title, name) {
        var timeArr = [];
        var dataArr = [];
        for (var i = 0; i < data.length; i++) {
            timeArr.push(data[i].days);
            dataArr.push(data[i].Count || data[i].Fee || 0);
        }
        chart = echarts.init(document.getElementById(id));
        option = {
            title: {
                text: title,
            },
            tooltip: {
                trigger: 'axis'
            },
            calculable: true,
            xAxis: [{
                type: 'category',
                boundaryGap: false,
                data: timeArr,
                axisLine: {
                    lineStyle: {
                        color: '#999',
                        width: 1
                    }
                }
            }],
            yAxis: [{
                type: 'value',
                axisLabel: {
                    formatter: '{value}'
                },
                axisLine: {
                    lineStyle: {
                        color: '#999',
                        width: 1
                    }
                }
            }],
            series: [{
                name: name,
                type: 'line',
                data: dataArr,
                markPoint: {
                    data: [{
                        type: 'max',
                        name: '最大值'
                    },
                        {
                            type: 'min',
                            name: '最小值'
                        }
                    ],
                    itemStyle: {
                        normal: {
                            color: '#3254a9',
                            lineStyle: {
                                color: '#3254a9'
                            }
                        }
                    }
                },
                markLine: {
                    data: [{
                        type: 'average',
                        name: '平均值'
                    }],
                    itemStyle: {
                        normal: {
                            color: '#3254a9',
                            lineStyle: {
                                color: '#3254a9'
                            }
                        }
                    }
                },
                itemStyle: {
                    normal: {
                        color: '#3254a9',
                        lineStyle: {
                            color: '#3254a9'
                        }
                    }
                }
            },]
        };
        chart.setOption(option);
        $(window).resize(chart.resize);
    },
    /**
     * param 将要转为URL参数字符串的对象
     * key URL参数字符串的前缀
     * encode true/false 是否进行URL编码,默认为true
     *
     * return URL参数字符串
     */
    urlEncode: function (param, encode, key) {
        if (param == null) return '';
        var paramStr = '';
        var t = typeof(param);
        if (t == 'string' || t == 'number' || t == 'boolean') {
            paramStr += '&' + key + '=' + ((encode == null || encode) ? encodeURIComponent(param) : param);
        } else {
            for (var i in param) {
                var k = key == null ? i : key + (param instanceof Array ? '[' + i + ']' : '.' + i);
                paramStr += this.urlEncode(param[i], encode, k);
            }
        }
        return paramStr;
    },
    getCookies: function (name) {
        var arr, reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");
        if (arr = document.cookie.match(reg))
            return unescape(arr[2]);
        else
            return null;
    },
    //session过期
    setCookie2: function (name, value, domain, path, secure) {
        var text = name + "=" + escape(value)
        if (domain) {
            text += '; domain=' + domain;
        }
        if (path) {
            text += '; path=' + path;
        }
        if (secure) {
            text += '; secure';
        }
        document.cookie = text;
    },
    setCookie: function (name, value, expires, domain, path, secure) {
        if (null == expires || 0 >= expires) var n = 300;
        var r = new Date;
        // 24*60*60*1000 = 86400000
        r.setTime(r.getTime() + expires * 86400000);
        var text = name + "=" + escape(value) + ";" + "expires=" + r.toGMTString();
        if (domain) {
            text += '; domain=' + domain;
        }
        if (path) {
            text += '; path=' + path;
        }
        if (secure) {
            text += '; secure';
        }
        document.cookie = text;
    },
    // alert: function(tips) {
    //     alert(tips);
    // },
    pageInit: function ($ele, pageIndex, pageSize, totalRow, pgobj, url, conditionObj) {
        $ele.pagination(totalRow, {
            num_edge_entries: 2,
            num_display_entries: 4,
            prev_text: '上一页',
            next_text: '下一页',
            link_to: 'javascript:void(0);',
            current_page: pageIndex - 1,
            prev_show_always: true,
            next_show_always: true,
            callback: function (page_index, jq) {
                if ((page_index + 1) == pageIndex) {
                    return;
                }
                pgobj.currenIndex = page_index + 1;
                if (pgobj.getList2) {
                    pgobj.getList2(page_index + 1, url, conditionObj);
                } else {
                    pgobj.getList(page_index + 1, url, conditionObj);
                }
            },
            items_per_page: pageSize
        });
    },

    getFormData: function ($form) {
        var formData = $form.serializeObject();
        console.log(formData)
        for (var key in formData) {
            console.log(key)
            var $curEle = $('input[name="' + key + '"]');
            var notTip = $curEle.attr('nottip');
            var isEmpty = false;
            //获取输入框前面的文字
            var txt = $curEle.parent().parent().find('label').text();

            var type = $curEle.attr('type').toLowerCase();
            if (type == 'checkbox') {
                var checkedLen = $('input[name="permission"]:checked').length;
                if (checkedLen == 0) {
                    txt = $curEle.parent().parent().parent().parent().children('label').text();
                    isEmpty = true;
                }
                formData[key] = [].concat(formData[key]);
            } else if (type == 'text') {
                txt = $curEle.parent().parent().find('label').text();
                if (!notTip) {
                    isEmpty = true;
                }
            }

            if (txt) {
                txt = txt.replace(/[:|：]/g, '');
            }
            if (isEmpty) {
                util.alert(txt + '不能为空');
                return false;
            }
        }

        return {
            uid: util.getCookies(util.runFlag),
            json: formData
        };

    },

    // 单位换算，默认kb
    getUnit: function (intNumber) {
        intNumber = parseInt(intNumber);
        var units = ["KB", "MB", "GB", "TB", "PB"];
        var obj = {
            MB: 1024,
            GB: 1024 * 1024,
            TB: 1024 * 1024 * 1024,
            PB: 1024 * 1024 * 1024 * 1024,
            // PB: 1024 * 1024 * 1024 * 1024 * 1024
        };

        for (var i = 0; i < units.length; i++) {
            if (Math.floor(intNumber / obj[units[i]]) < 1000) {
                return (intNumber / obj[units[i]]).toFixed(2) + units[i];
            }
        }
    }
};

$.fn.serializeObject = function () {
    var o = {};
    var a = this.serializeArray();
    $.each(a, function () {
        if (o[this.name] !== undefined) {
            if (!o[this.name].push) {
                o[this.name] = [o[this.name]];
            }
            o[this.name].push(this.value || '');
        } else {
            o[this.name] = this.value || '';
        }
    });
    return o;
};

$(function () {
    $('a[name="logout"]').on('click', function () {
        util.setCookie("runUId", '', -1, null, "/", null);
        util.setCookie("runUName", '', -1, null, "/", null);
        window.location.href = '/member/login';
    })
});

$(document).on('input', '.price, .number', function () {
    $(this).val($(this).val().replace(/[^\d.]/g, ''));
});

$(document).on('focus', 'input', function () {
    $('input[type="text"]').attr('autocomplete', 'off');
});