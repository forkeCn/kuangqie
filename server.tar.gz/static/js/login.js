window.loginObj = window.loginObj || {};

$(function () {
    loginObj.init();
});

loginObj = {
    init: function () {
        this.bindEvent();
    },
    bindEvent: function () {
        var that = this;

        $('.btn-login').on('click', function () {
            var username = $('input[name="username"]').val();
            var password = $('input[name="password"]').val();
            if (!username) {
                layer.alert('请输入用户名！');
                return;
            } else if (!password) {
                layer.alert('请输入密码！');
                return;
            } else {
                that.doLogin(username, password);
            }
        });

        // $(document).on('keyup', function (event) {
        //     var event = event || window.event;
        //     console.log(event);
        // });
    },
    doLogin: function (username, password) {
        $.ajax({
            url: "/loginApi",
            data: {
                username: username,
                password: password
            },
            dataType: 'json',
            type: 'post',
            success: function (res) {
                if (res.code == 200) {
                    var data = JSON.parse(res.data);
                    sessionStorage.setItem("user_name", data.username);
                    sessionStorage.setItem("id", data.id);

                    layer.msg('登录成功...', {time: 1000, icon: 0}, function () {
                        window.location.href = '/index';
                    });
                } else {
                    layer.msg(res.msg, {time: 1000, icon: 0});
                }
            },
            error: function () {
                layer.msg('服务器异常，请联系管理员', {time: 1000, icon: 0});
            }
        });
    }
};