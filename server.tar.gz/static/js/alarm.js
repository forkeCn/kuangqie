window.alarmObj = window.alarmObj || {};

$(function () {
    alarmObj.init();
});

alarmObj = {
    init: function () {
        this.page = 1;
        this.limit = 10;
        this.bindEvent();
        this.getList(this.page);
    },
    bindEvent: function () {
        var that = this;

        //新增警报规则
        $("#add_rule").on("click", function () {

            layer.open({
                title: '新增规则',
                content: $("#add_rule_temp").html(),
                resize: false,
                area: ['800px', "auto"],
                btn: ['确定', '取消'],
                yes: function () {
                    var ruleName = $("#ruleName").val().trim();
                    var ruleOption = $("#ruleOption").val().trim();
                    var watchTime = $("#watchTime").val().trim();
                    var isHigher = $("#isHigher").val().trim();
                    var threshold = $("#threshold").val().trim();
                    var silentTime = $("#silentTime").val().trim();
                    var frequency = $("#frequency").val().trim();
                    var noticeType = 2;
                    var noticeTarget = $("#noticeTarget").val().trim();

                    var data = {
                        ruleName: ruleName,
                        ruleOption: ruleOption,
                        watchTime: watchTime || 1,
                        isHigher: isHigher || 1,
                        threshold: threshold || 100,
                        silentTime: silentTime || 1,
                        frequency: frequency || 1,
                        noticeType: noticeType || 2,
                        noticeTarget: noticeTarget
                    };

                    if (noticeType == "2" && !util.checkEmail(noticeTarget)) {
                        return util.alert("邮箱格式错误");
                    }

                    $.ajax({
                        url: "/addAlarmRuleApi",
                        data: {
                            ruleInfo: JSON.stringify(data)
                        },
                        dataType: 'json',
                        type: 'post',
                        success: function (res) {
                            layer.msg(res.msg);
                            if (res.code == "200") {
                                setTimeout(function () {
                                    window.location.reload();
                                }, 1500);
                            }
                        }
                    })
                }
            })
        });

        //启用/禁用
        $(document).on("click", ".opera-switch", function () {
            var id = $(this).data("id");
            var state = $(this).attr("state");

            if (!id) return layer.msg("缺少ID");

            $.ajax({
                url: "/switchRuleStateApi",
                type: "post",
                dataType: "json",
                data: {
                    id: id,
                    state: state == 1 ? 0 : 1
                },
                success: function (res) {
                    layer.msg(res.msg);
                    if (res.code == "200") {
                        setTimeout(function () {
                            window.location.reload();
                        }, 1500);
                    }
                }
            })
        });

        // 编辑
        $(document).on("click", ".opera-down", function () {
            var id = $(this).data("id");
            if (!id) return layer.msg("缺少ID");

            $.ajax({
                url: "/ruleInfoApi",
                type: "post",
                dataType: "json",
                data: {
                    id: id
                },
                success: function (res) {
                    if (res.code == "200") {
                        var data = JSON.parse(res.data);

                        layer.open({
                            title: '编辑规则',
                            content: $("#add_rule_temp").html(),
                            resize: false,
                            area: ['800px', "auto"],
                            btn: ['确定', '取消'],
                            success: function () {
                                $("#ruleName").val(data.RuleName);
                                $("#ruleOption").val(data.RuleOption);
                                $("#watchTime").val(data.WatchTime);
                                $("#isHigher").val(data.IsHigher);
                                $("#threshold").val(data.Threshold);
                                $("#silentTime").val(data.SilentTime);
                                $("#frequency").val(data.Frequency);
                                $("#noticeTarget").val(data.NoticeTarget);

                                var state = $("#ruleOption").val().trim();

                                if (state == "2") {
                                    $(".unit").html("℃");
                                } else {
                                    $(".unit").html("%");
                                }
                            },
                            yes: function () {
                                var ruleName = $("#ruleName").val().trim();
                                var ruleOption = $("#ruleOption").val().trim();
                                var watchTime = $("#watchTime").val().trim();
                                var isHigher = $("#isHigher").val().trim();
                                var threshold = $("#threshold").val().trim();
                                var silentTime = $("#silentTime").val().trim();
                                var frequency = $("#frequency").val().trim();
                                var noticeType = 2;
                                var noticeTarget = $("#noticeTarget").val().trim();

                                var data = {
                                    ruleName: ruleName,
                                    ruleOption: ruleOption,
                                    watchTime: watchTime || 1,
                                    isHigher: isHigher || 1,
                                    threshold: threshold || 100,
                                    silentTime: silentTime || 1,
                                    frequency: frequency || 1,
                                    noticeType: noticeType || 2,
                                    noticeTarget: noticeTarget
                                };

                                if (noticeType == "2" && !util.checkEmail(noticeTarget)) {
                                    return util.alert("邮箱格式错误");
                                }

                                $.ajax({
                                    url: "/editRuleApi",
                                    data: {
                                        id: id,
                                        ruleInfo: JSON.stringify(data)
                                    },
                                    dataType: 'json',
                                    type: 'post',
                                    success: function (res) {
                                        layer.msg(res.msg);
                                        if (res.code == "200") {
                                            setTimeout(function () {
                                                window.location.reload();
                                            }, 1500);
                                        }
                                    }
                                })
                            }
                        });
                    }
                }
            });
        });

        //删除
        $(document).on("click", ".opera-delete", function () {
            var id = $(this).data("id");
            if (!id) return layer.msg("缺少ID");

            $.ajax({
                url: "/deleteRuleApi",
                type: "post",
                dataType: "json",
                data: {
                    id: id
                },
                success: function (res) {
                    layer.msg(res.msg);
                    if (res.code == "200") {
                        setTimeout(function () {
                            window.location.reload();
                        }, 1500);
                    }
                }
            })
        });

        //阈值单位切换
        $(document).on("change", "#ruleOption", function () {
            var state = $(this).val().trim();

            if (state == "2") {
                $(".unit").html("℃");
            } else {
                $(".unit").html("%");
            }
        });
    },

    getList: function (page) {
        var that = this;
        $.ajax({
            url: "/ruleListApi",
            data: {
                page: page || 1,
                limit: 10
            },
            dataType: 'json',
            type: 'post',
            success: function (res) {
                if (res.code == 200) {
                    var list = JSON.parse(res.data);
                    var pages = JSON.parse(res.pages);
                    var totalRow = pages.TotalRow;
                    var pageSize = pages.PageSize;
                    var pageIndex = pages.PageIndex;

                    if (!list || !list.length) return $("#rule_list").html("暂无数据");

                    var temp = $('#list_temp').html();
                    var ejs = new EJS({text: temp, type: '['});
                    var html = ejs.render({data: list, pages: pages});
                    $("#rule_list").html(html);

                    if (totalRow / pageSize <= 1) {
                        $("#listPagination").hide();
                    } else {
                        $("#listPagination").show();
                    }
                    util.pageInit($("#listPagination"), pageIndex, pageSize, totalRow, alarmObj);
                } else {
                    layer.msg(res.msg, {time: 1000, icon: 0});
                }
            },
            error: function () {
                layer.msg('服务器异常，请联系管理员', {time: 1000, icon: 0});
            }
        });

    }
};