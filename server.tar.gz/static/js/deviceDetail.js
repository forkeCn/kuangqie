window.deviceDetailObj = window.deviceDetailObj || {};

$(function () {
    var userId = sessionStorage.getItem("id");
    if (!userId) {
        return window.location.href = "/";
    }
    deviceDetailObj.itemId = util.QueryString('id') || '';
    deviceDetailObj.cpuCores = util.QueryString('core') || 1;
    deviceDetailObj.disk = util.QueryString('disk') || 1;
    deviceDetailObj.wakeOn = parseInt(util.QueryString("wakeOn")) || 0;
    deviceDetailObj.ip = util.QueryString("ip") || "";

    deviceDetailObj.init();
});

deviceDetailObj = {
    itemId: '',
    value: 1,
    time: "1h",
    option: "0",
    _flag: "",
    timeStamps: [],
    MemTimeStamps: [],

    CPU_percent_y: [],
    CPU_temperature_y: [],
    Memory_percent_y: [],
    Net_up_down_y: [],
    Net_up: [],
    Net_down: [],
    // Disk_IO_y: [],
    Disk_percent_y: [],
    diskName: [],

    timeline: [],

    chartEntity: null,
    chartMember: {
        "CPU_percent": null,
        "CPU_temperature": null,
        "Memory_percent": null,
        "Net_up_down": null,
        // "Disk_IO": null,
        "Disk_percent": null
    },

    legendMember: {
        "CPU": [],
        "Disk": [],
        "Net": ["上行速度", "下行速度"]
    },

    init: function () {
        var that = this;
        this.bindEvent();

        // if (!this.wakeOn) {
        //     $('.wake-on').hide();
        //     $(".wake-off").show();
        // } else {
        //     $('.wake-off').hide();
        //     $(".wake-on").show();
        // }
        for (var i = 0; i < this.cpuCores; i++) {
            this['CPU_percent_y_' + i] = [];
            this['CPU_temperature_y_' + i] = [];
            this.legendMember.CPU.push("CPU" + (i + 1));
        }

        for (var i = 0; i < this.disk; i++) {
            this['disk_percent_y_' + i] = [];
            this.legendMember.Disk.push("DISK" + (i + 1));
        }

        this.getMachineMinerType();
        this.getServerStatData();
        // setInterval(function () {
        //     that.getServerStatData();
        // }, 1000 * 2 );

    },
    bindEvent: function () {
        var that = this;
        $("#web_ssh").on("click", function () {
            var ip = $(this).find(".ssh-operate").attr("ip")
            window.open(`/shell?proto=ssh&&ipaddr=${ip}&&port=22&&user=root`)
        })

        $("#wake_on").on("click", function () {
            $.ajax({
                url: "/deviceWakeOnApi",
                dataType: "json",
                type: "post",
                data: {
                    ipAddr: that.ip,
                    macAddress: that.itemId
                },
                success: function (res) {
                    layer.alert("系统正在开机，请稍后..");
                }
            });
        });

        $("#wake_off").on("click", function () {
            $.ajax({
                url: "/deviceWakeOffApi",
                dataType: "json",
                type: "post",
                data: {
                    ipAddr: that.ip,
                    macAddress: that.itemId
                },
                success: function (res) {
                    layer.alert("系统正在关机，请稍后..");
                }
            });
        });

        //总览和单独查看
        $('.switch-icon').on('click', function () {
            $('.switch-icon').css({"background": "#E8ECEF"});
            $(this).css({"background": "#fff"});
            var value = $(this).attr('value');
            that.value = value;
            var activeVal = $('.view-option-item').filter('.active-tap').attr('value');

            $('.view-option-item').removeClass('active-tap').eq(0).addClass('active-tap');
            $('.time-zone-item').removeClass('active-tap').eq(0).addClass('active-tap');

            if (value === "2") {
                $('.view-box').show();

                $('.chart-list').not($('.chart-list').eq(activeVal)).hide();
                $('.col-md-6').css({"width": "80%"});
            } else {
                $('.view-box').hide();
                $('.col-md-6').css({"width": "50%"});
                $('.chart-list').show();
            }

            that.option = "0";
            that.time = "1h";

            that.getServerStatData();
        });

        //单独查看的 项
        $('.view-option-item').on('click', function () {
            if (that.value != '2') return;
            $('.view-option-item').removeClass('active-tap');
            $(this).addClass('active-tap');

            var option = $(this).attr('value');
            that.option = option;
            that.initData();
            that.getServerStatData();
        });

        //时间段
        $('.time-zone-item').on('click', function () {
            if (that.value != '2') return;
            $('.time-zone-item').removeClass('active-tap');
            $(this).addClass('active-tap');

            var time = $(this).attr('value');
            that.time = time;
            that.initData();
            that.getServerStatData();
        });

        //查看日志
        $(document).on("click", ".view-logs", function () {
            var minerTypeId = $(this).attr("value");
            var path = $(this).attr("path");
            var processName = $(this).attr("processname");

            var html = '<div id="logsContent" style="min-height: 300px;"></div>';

            layer.open({
                title: '日志',
                content: html,
                resize: false,
                btn: false,
                area: ['500px', "auto"],
                success: function () {
                    that.getLogs(minerTypeId, "true", path, processName, function () {
                        that._flag = setInterval(function () {
                            that.getLogs(minerTypeId, "false", path, processName)
                        }, 3 * 1000)
                    })
                },
                end: function () {
                    clearInterval(that._flag)
                }
            });
        });
    },

    getLogs: function (minerTypeId, isfirst, path, processName, callback) {
        var that = this;
        util.ajax("/viewLogsApi", {
            macAddress: that.itemId,
            minerTypeId: minerTypeId,
            path: path,
            proname: processName,
            first: isfirst
        }, function (result) {
            if (result.code == 200) {
                var data = (result.data) || "";

                $("#logsContent").append(data);
                callback && callback()
            } else {
                layer.msg(result.msg);
            }
        });
    },

    getServerStatData: function () {
        var that = this;
        that.initData();

        $.ajax({
            url: "/deviceDetailApi",
            data: {
                itemId: that.itemId,
                viewType: that.value,
                time: that.time,
                viewOption: that.option
            },
            dataType: "json",
            type: "post",
            success: function (res) {
                if (res.code == 200) {
                    var data = JSON.parse(res.data);
                    var now = new Date().getTime();

                    if (!data || !data.length) {
                        return layer.msg("暂无数据", {time: 1000, icon: 0});
                    }
                    // $('.ssh-operate').attr("ip", data[0].Ip);
                    $('.ssh-operate').attr("ip", that.ip);

                    data = data.reverse();

                    if (that.value == 1 || that.option == 4) {
                        that.diskName = JSON.parse(data[0].DiskName);
                        for (var i = 0; i < that.diskName.length; i++) {
                            var arr = that.diskName[i].split("/");
                            that.legendMember.Disk[i] = arr[arr.length - 1];
                        }
                    }

                    for (var item of data) {
                        that.timeStamps.push(moment(item.SaveTime).format("HH:mm"));
                        that.MemTimeStamps.push(moment(item.SaveTime).format("HH:mm"));

                        var cpuPercent, cpuTemperature, diskPercent;

                        if (item.CpuPercent) cpuPercent = JSON.parse(item.CpuPercent);
                        if (item.CpuTemperature) cpuTemperature = JSON.parse(item.CpuTemperature);
                        if (item.DiskPercent) diskPercent = JSON.parse(item.DiskPercent);

                        var args_p = [], args_t = [], args_d = [];
                        for (var i = 0; i < that.cpuCores; i++) {
                            if (cpuPercent) {
                                that['CPU_percent_y_' + i].push(cpuPercent[i].toFixed(2));
                                args_p.push(that['CPU_percent_y_' + i]);
                            }
                            if (cpuTemperature) {
                                that['CPU_temperature_y_' + i].push(cpuTemperature[i]);
                                args_t.push(that['CPU_temperature_y_' + i]);
                            }
                        }

                        for (var i = 0; i < that.disk; i++) {
                            if (diskPercent) {
                                that['disk_percent_y_' + i].push(diskPercent[i].toFixed(2));
                                args_d.push(that['disk_percent_y_' + i]);
                            }
                        }

                        if (item.NetUp) that.Net_up.push(item.NetUp);
                        if (item.NetDown) that.Net_down.push(item.NetDown);

                        if (item.MemoryPercent) that.Memory_percent_y.push(item.MemoryPercent);
                        if (item.DiskPercent) that.Disk_percent_y.push(item.DiskPercent);
                        // if (item.DiskIO) that.Disk_IO_y.push(item.DiskIO);
                    }
                    that.Net_up_down_y.push(that.Net_up, that.Net_down);

                    if (that.value == '1') {
                        for (var i in that.chartMember) {
                            var chart = that.chartMember[i];
                            if (chart) chart.resize();
                        }

                        that.initChart("CPU_percent", "CPU使用率(%)", args_p, "", that.legendMember.CPU);
                        that.initChart("CPU_temperature", "CPU温度(°C)", args_t, "", that.legendMember.CPU);
                        that.initChart("Memory_percent", "内存使用率(%)", [that.Memory_percent_y], "");
                        that.initChart("Net_up_down", "上下行速率(kb/s)", that.Net_up_down_y, "", that.legendMember.Net);
                        // that.initChart("Disk_IO", "磁盘IO", [that.Disk_IO_y], "M/s");
                        that.initChart("Disk_percent", "磁盘使用率(%)", args_d, "", that.legendMember.Disk);
                    } else if (that.value == '2') {
                        $('.chart-list').hide().eq(that.option).show();
                        var actEle = $('.chart-item').eq(that.option)[0];

                        switch (that.option) {
                            case "0":
                                that.chartMember.CPU_percent.resize();
                                that.initChart("CPU_percent", "CPU使用率(%)", args_p, "", that.legendMember.CPU);
                                break;
                            case "1":
                                that.chartMember.CPU_temperature.resize();
                                that.initChart("CPU_temperature", "CPU温度(°C)", args_t, "", that.legendMember.CPU);
                                break;
                            case "2":
                                that.chartMember.Memory_percent.resize();
                                that.initChart("Memory_percent", "内存使用率(%)", [that.Memory_percent_y], "");
                                break;
                            case "3":
                                that.chartMember.Net_up_down.resize();
                                that.initChart("Net_up_down", "上下行速率(kb/s)", that.Net_up_down_y, "", that.legendMember.Net);
                                break;
                            // case "4":
                            //     that.chartMember.Disk_IO.resize();
                            //     that.initChart("Disk_IO", "磁盘IO", [that.Disk_IO_y], "M/s");
                            //     break;
                            case "4":
                                that.chartMember.Disk_percent.resize();
                                that.initChart("Disk_percent", "磁盘使用率(%)", args_d, "", that.legendMember.Disk);
                                break;
                        }
                    }
                } else {
                    layer.msg(res.msg, {time: 1000, icon: 0});
                }
            },
            error: function () {
                layer.msg('服务器异常，请联系管理员', {time: 1000, icon: 0});
            }
        });
    },

    getMachineMinerType: function () {
        var that = this;

        $.ajax({
            url: "/machineMinerTypeApi",
            data: {
                macAddress: that.itemId
            },
            dataType: "json",
            type: "post",
            success: function (res) {
                if (res.code == '200') {
                    var data = JSON.parse(res.data);
                    if (!data) return;

                    var temp = '';
                    for (var item of data) {
                        temp += '<span class="btn btn-primary view-logs" value="' + item.Id + '" path="' + item.LogPath
                            + '" processname="' + item.ProcessName + '">' + item.MinerName + '日志</span>';
                    }

                    $(".logs-box").html('').html(temp);
                } else {
                    layer.msg(res.msg, {time: 1000, icon: 0});
                }
            }
            , error: function () {
                layer.msg('服务器异常，请联系管理员', {time: 1000, icon: 0});
            }
        })
    },

    initData: function () {
        this.CPU_percent_y = [];
        this.CPU_temperature_y = [];
        this.Memory_percent_y = [];
        this.Net_up_down_y = [];
        this.Net_up = [];
        this.Net_down = [];
        // this.Disk_IO_y = [];
        this.Disk_percent_y = [];
        this.timeline = [];
        this.timeStamps = [];
        this.MemTimeStamps = [];
    },

    initChart: function (eleId, title, data, unit, legend) {
        var that = this;
        var colorArr = ["#337ab7", "#e43c59", "#2f4554", "#de7e7b"];

        that.chartMember[eleId] = echarts.init($('#' + eleId)[0]);

        var options = {
            title: {
                text: title
            },
            tooltip: {
                trigger: 'axis'
            },
            calculable: true,
            legend: {
                data: legend
            },
            xAxis: {
                type: 'category',
                splitLine: {show: true},
                data: that.timeStamps,
                boundaryGap: false
            },
            dataZoom: [{
                xAxisIndex: 0,
                show: false,
                type: 'slider',
                startValue: 0,
                endValue: 100
            }],
            yAxis: {
                type: 'value',
                axisLabel: {
                    show: true,
                    interval: 'auto',
                    formatter: '{value} ' + unit
                },
                show: true,
                splitLine: {show: true}
            },
            series: []
        };

        for (var i = 0; i < data.length; i++) {
            var name = '';
            if (legend && legend.length) {
                name = legend[i];
            }
            options.series.push({
                name: name,
                type: 'line',
                data: data[i],
                symbol: 'emptyCircle',
                lineStyle: {
                    color: colorArr[i],
                    width: 1
                }
            });
        }

        that.chartMember[eleId].setOption(options);
        $(window).resize(that.chartMember[eleId].resize);
    }
};
