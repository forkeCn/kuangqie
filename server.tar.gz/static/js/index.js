$(function () {
    var userId = sessionStorage.getItem("id");
    if (!userId) {
        return window.location.href = "/";
    }
    indexObj.init();
    indexObj.bindEvent();
});
var indexObj = {
    page: 1,
    init: function () {
        var that = this;
        this.getData();
        this.initChart();
        // setInterval(function() { //轮询是否有新设备上线
        //     that.getList();
        // }, 1000 * 30)
    },
    getData: function () {
        var that = this;
        util.ajax("/indexCountDataApi", {}, function (result) {
            if (result.code == 200) {
                var data = JSON.parse(result.data);

                $("#MachineTotal").html($("#MachineTotal").html().replace('num', data.MachineTotal));
                $("#MachineOpen").html($("#MachineOpen").html().replace('num', data.MachineOpen));
                $("#MachineClose").html($("#MachineClose").html().replace('num', data.MachineClose));
                $("#DiskTotal").html($("#DiskTotal").html().replace('num', util.getUnit(data.DiskTotal)));
                $("#DiskUsing").html($("#DiskUsing").html().replace('num', util.getUnit(data.DiskUsing)));
                $("#CpuTotal").html($("#CpuTotal").html().replace('num', data.CpuTotal));
                $("#CpuUsing").html($("#CpuUsing").html().replace('num', data.CpuUsing));
                $("#CpuFull").html($("#CpuFull").html().replace('num', data.CpuFull));
                $("#Bandwidth_up").html($("#Bandwidth_up").html().replace('num', (data.NetUp / 1024).toFixed(2)));
                $("#Bandwidth_down").html($("#Bandwidth_down").html().replace('num', (data.NetDown / 1024).toFixed(2)));
            } else {
                layer.msg(result.msg);
            }
        })
    },
    bindEvent: function () {
        var that = this;
        $("#login_out").on("click", function () {
            layer.confirm("确定退出吗？", function (idx) {
                layer.close(idx);
                window.location.href = '/';
            })
        });

        $("#select_span span").on("click", function () {
            var flag = $(this).attr("flag");
            $("#select_span span").removeClass("label-primary-cur");
            $(this).addClass("label-primary-cur");

            that.initChart()
        });
    },

    initChart: function () {
        var that = this;

        $.ajax({
            url: "/indexChartDataApi",
            type: "post",
            dataType: "json",
            data: {},
            success: function (res) {
                if (res.code == "200") {
                    var data = JSON.parse(res.data);
                    if (!data) return

                    that.drawRingChart(data)
                }
            }
        });
    },

    drawRingChart: function (data) {
        var that = this;

        var arr = [];
        for (var k in data) {
            if (data.hasOwnProperty(k)) arr.push(k);
        }

        for (var key of arr) {
            var showData;
            var echartsItem = echarts.init($("#" + key)[0]);

            switch (key) {
                case 'allCount':
                    showData = data.allCount;
                    that.allCount = data.all;
                    $("#allCountTitle").html("总数");
                    break;
                case 'todayCount':
                    showData = data.todayCount;
                    $("#todayCountTitle").html("今日总数");
                    break;
                case 'weekCount':
                    showData = data.weekCount;
                    $("#weekCountTitle").html("本周总数");
                    break;
                case 'monthCount':
                    showData = data.monthCount;
                    $("#monthCountTitle").html("本月总数");
                    break;
            }
            var percent = 0;
            if (that.allCount != 0) {
                percent = showData / that.allCount;
            }
            var option = that.getChartOption(percent, showData);
            echartsItem.setOption(option);
            $(window).resize(echartsItem.resize)
        }
    },
    getChartOption: function (percent, count) {
        var placeHolderStyle = {
            normal: {
                label: {
                    show: false
                },
                position: 'center',
                labelLine: {
                    show: false
                },
                color: "rgba(0,0,0,0)",
                borderWidth: 0
            },
            emphasis: {
                color: "rgba(0,0,0,0)",
                borderWidth: 0
            }
        };
        var lightBlue = {
            x: 0,
            y: 0,
            x2: 0,
            y2: 1,
            colorStops: [{
                offset: 0,
                color: 'red' // 0% 处的颜色
            }, {
                offset: 1,
                color: '#cc00a3' // 100% 处的颜色
            }],
            globalCoord: false // 缺省为 false
        };

        var lightBlueBorder = {
            x: 0,
            y: 0,
            x2: 0,
            y2: 1,
            colorStops: [{
                offset: 0,
                color: '#0056aa' // 0% 处的颜色
            }, {
                offset: 1,
                color: '#1890d0' // 100% 处的颜色
            }],
            globalCoord: false // 缺省为 false
        };

        return {
            graphic: [{
                type: 'text',
                left: '49%',
                top: '46%',
                style: {
                    text: count,
                    fill: '#0056aa',
                    width: 40,
                    height: 20,
                    fontSize: 18,
                }
            }],

            series: [{
                type: 'pie',
                hoverAnimation: false, //鼠标经过的特效
                radius: ['70%', '55%'],
                center: ['50%', '50%'],
                startAngle: 225,
                z: 3,
                labelLine: {
                    normal: {
                        show: false
                    }
                },
                label: {
                    normal: {
                        position: 'center'
                    }
                },
                data: [{
                    value: percent * 100,
                    itemStyle: {
                        normal: {
                            color: lightBlue
                        }
                    },
                    //	label: passDataStyle,
                }, {
                    value: 133.3 - percent * 100,
                    itemStyle: placeHolderStyle,
                }]
            },


                //外圈的边框
                {
                    type: 'pie',
                    hoverAnimation: false, //鼠标经过的特效
                    radius: ['70%', '55%'],
                    center: ['50%', '50%'],
                    startAngle: 225,
                    z: 2,
                    labelLine: {
                        normal: {
                            show: false
                        }
                    },
                    label: {
                        normal: {
                            position: 'center'
                        }
                    },
                    data: [{
                        value: 75,
                        itemStyle: {
                            normal: {
                                color: lightBlueBorder
                            }
                        },
                    }, {
                        value: 25,
                        itemStyle: placeHolderStyle,
                    }]
                }]
        };
    }

};