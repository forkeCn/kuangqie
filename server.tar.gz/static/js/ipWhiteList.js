window.ipWhiteListObj = window.ipWhiteListObj || {};

$(function () {
    var userId = sessionStorage.getItem("id");
    if (!userId) {
        return window.location.href = "/";
    }
    ipWhiteListObj.init();
});

ipWhiteListObj = {
    flag: "",
    macAddressArr: [],
    init: function () {
        this.page = 1;
        this.limit = 10;
        this.bindEvent();
        this.getList(this.page);
    },
    bindEvent: function () {
        var that = this;

        //添加白名单
        $(document).on("click", "#addMiner", function () {
            var html = $('#add_miner_temp').html();

            layer.open({
                title: '添加IP白名单',
                content: html,
                btn: ['提交', '取消'],
                resize: false,
                area: ['650px', "auto"],
                yes: function () {
                    var ip = $('#ip').val().trim();

                    if (!ip) return layer.tips('矿名称不能为空', '#minerName');

                    var data = {
                        ip: ip
                    };

                    util.ajax("/setIpWhiteListApi", data, that._succFn, that._errFn);
                },
                btn2: function () {
                    var index = layer.open();
                    layer.close(index);
                }
            });
        });

        //删除
        $(document).on("click", ".delete", function () {
            var ip = $(this).data("ip");

            layer.confirm("确定要删除吗？", {btn: ["确定", "取消"]}, function () {
                if (!ip) return layer.msg("缺少IP");

                $.ajax({
                    url: "/deleteIpWhiteListApi",
                    type: "post",
                    dataType: "json",
                    data: {
                        ip: ip
                    },
                    success: function (res) {
                        layer.msg(res.msg, {time: 1000, icon: 0});
                        that.getList(that.page);
                    }
                });
            });
        });
    },

    getList: function (page) {
        $.ajax({
            url: "/ipWhiteListApi",
            data: {
                page: page || 1,
                limit: 10
            },
            dataType: 'json',
            type: 'post',
            success: function (res) {
                if (res.code == 200) {
                    var list = JSON.parse(res.data);
                    var pages = JSON.parse(res.pages);
                    var totalRow = pages.TotalRow;
                    var pageSize = pages.PageSize;
                    var pageIndex = pages.PageIndex;

                    if (!list || !list.length) {
                        return $("#logs_pos").html("暂无数据");
                    }

                    var temp = $('#list_temp').html();
                    var ejs = new EJS({text: temp, type: '['});
                    var html = ejs.render({data: list, pages: pages});
                    $("#logs_pos").html(html);

                    if (totalRow / pageSize <= 1) {
                        $("#listPagination").hide();
                    } else {
                        $("#listPagination").show();
                    }
                    util.pageInit($("#listPagination"), pageIndex, pageSize, totalRow, ipWhiteListObj);
                } else {
                    layer.msg(res.msg, {time: 1000, icon: 0});
                }
            },
            error: function () {
                layer.msg('服务器异常，请联系管理员', {time: 1000, icon: 0});
            }
        });

    },

    _succFn: function (data) {
        if (data && data.code == 400) {
            window.location.href = '/login';
        } else {
            layer.msg(data.msg, {time: 1000, icon: 0});
            ipWhiteListObj.getList(ipWhiteListObj.page);
        }
    },

    _errFn: function () {
        layer.alert("与服务器通信错误");
    }
};