window.sysSettingObj = window.sysSettingObj || {};

$(function () {
    var userId = sessionStorage.getItem("id");
    if (!userId) {
        return window.location.href = "/";
    }
    sysSettingObj.init();
});

sysSettingObj = {
    init: function () {
        this.page = 1;
        this.limit = 10;
        this.bindEvent();
        this.getIpPool();
        this.getPassword();
    },
    bindEvent: function () {
        var that = this;

        $(document).on("click", "#white_list", function () {
            window.location.href = "/setIpWhiteList";
        });

        $(document).on("click", "#set_password", function () {
            // var username = $("#username").val() || "root";
            var password = $("#password").val();

            if (!password) return layer.alert("输入一个密码");

            $.ajax({
                url: "/setPassword",
                type: "post",
                dataType: "json",
                data: {
                    // username: username,
                    password: password
                },
                success: function (res) {
                    layer.msg(res.msg, {time: 1000});
                }
            })
        });

        $(document).on("click", "#clear_password", function () {
            $.ajax({
                url: "/clearPassword",
                type: "post",
                dataType: "json",
                success: function (res) {
                    layer.msg(res.msg, {time: 1000});
                    $("#password").val("");
                }
            })
        });

        //编辑
        $(document).on("click", "#commit", function () {
            var startIp = $("#start_ip").val();
            var endIp = $("#end_ip").val();

            if (!startIp && !endIp) return layer.msg("缺少IP地址");
            if (startIp == endIp) return layer.msg("起始IP和结束IP不可相同");

            $.ajax({
                url: "/setIpPool",
                data: {
                    startIp: startIp || "",
                    endIp: endIp || ""
                },
                dataType: "json",
                type: "post",
                success: function (res) {
                    layer.msg(res.msg, {time: 1000});
                },
                error: function () {
                    layer.msg('服务器异常，请联系管理员', {time: 1000, icon: 0});
                }
            });
        });

        //清除
        $(document).on("click", "#clear", function () {
            var startIp = $("#start_ip").val();
            var endIp = $("#end_ip").val();

            if (!startIp && !endIp) return layer.msg("缺少IP地址");
            if (startIp == endIp) return layer.msg("起始IP和结束IP不可相同");

            $.ajax({
                url: "/clearIpPool",
                data: {
                    startIp: startIp || "",
                    endIp: endIp || ""
                },
                dataType: "json",
                type: "post",
                success: function (res) {
                    $("#start_ip").val("");
                    $("#end_ip").val("");

                    layer.msg(res.msg, {time: 1000});
                },
                error: function () {
                    layer.msg('服务器异常，请联系管理员', {time: 1000, icon: 0});
                }
            });
        });
    },
    getIpPool: function () {
        $.ajax({
            url: "/getIpPool",
            dataType: "json",
            type: "post",
            success: function (res) {
                if (res.code == "200") {
                    var data = JSON.parse(res.data);

                    if (data && data.start && data.end) {
                        $("#start_ip").val(data.start);
                        $("#end_ip").val(data.end);
                    }
                } else {
                    layer.msg(res.msg, {time: 1000});
                }
            },
            error: function () {
                layer.msg('服务器异常，请联系管理员', {time: 1000, icon: 0});
            }
        });
    },

    getPassword: function () {
        $.ajax({
            url: "/getPassword",
            dataType: "json",
            type: "post",
            success: function (res) {
                if (res.code == "200") {
                    $("#password").val(res.data)
                }
            },
            error: function () {
                layer.msg('服务器异常，请联系管理员', {time: 1000, icon: 0});
            }
        });
    }
};