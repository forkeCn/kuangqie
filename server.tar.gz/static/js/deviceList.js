window.deviceListObj = window.deviceListObj || {};

$(function () {
    var userId = sessionStorage.getItem("id");
    if (!userId) {
        return window.location.href = "/";
    }


    deviceListObj.init();
});

deviceListObj = {
    page: 1,
    diskInfo: [],
    diskTotal: [],
    diskUsed: [],
    diskName: [],

    oldMinerArr: [],
    minerTypeArr: [],
    ipArr: [],

    init: function () {
        this.page = 1;
        this.limit = 10;
        this.bindEvent();
        this.getList(this.page);
    },
    bindEvent: function () {
        var that = this;
        var inter;

        $(document).on("click", ".tips-label", function () {
            that.ipArr = [];
            that.ipArr.push($(this).attr("ip"));

            $(this).children(".tips-ip").prop("selected", true);
        });

        $("#add_new_host").on("click", function () {
            $.post("/getPassword", {}, function (response) {
                if (response.code == "200") {
                    var idx = layer.load(2);

                    $.post("/addMachineApi", {}, function (result) {
                        layer.close(idx);

                        if (result.code == "200") {
                            var data = JSON.parse(result.data)
                            var len = data ? data.length : 0
                            if (len == 0) {
                                layer.alert("没有扫描到新的设备")
                                return false
                            }

                            var temp = $('#add_machine_tips').html();
                            var ejs = new EJS({text: temp, type: '['});
                            var html = ejs.render({data: data});

                            layer.open({
                                title: "选择机器IP",
                                content: html,
                                resize: false,
                                area: ['450px', "auto"],
                                btn: ["确定", "取消"],
                                closeBtn: 1,
                                success: function () {
                                    $(".layui-layer-content").css({"min-height": "120px"});
                                    $(".tips-title").html(`扫描到${len}台新设备，选择一个IP，并加入监控程序。`);
                                },
                                yes: function () {
                                    if (!that.ipArr.length) return layer.alert("请选择一台机器的IP");
                                    var ipStr = JSON.stringify(that.ipArr);

                                    var index = layer.open({
                                        title: "新增机器",
                                        content: $("#loading_process").html(),
                                        resize: false,
                                        area: ['800px', "auto"],
                                        btn: "",
                                        closeBtn: 0,
                                        move: false,
                                        success: function () {
                                            var width = 0;

                                            clearInterval(inter);
                                            inter = setInterval(function () {
                                                width += parseInt(Math.random() * 5);

                                                if (width >= 99) width = 99;

                                                $("#loading_bar").css("width", width + "%");
                                                $(".layui-progress-text").html(width == 0 ? "" : width + "%");
                                            }, 1500);

                                            setTimeout(function () {
                                                layer.close(index);
                                                clearInterval(inter)
                                            }, 1000 * 60 * 3);
                                        }
                                    });

                                    $.post("/execMachineApi", {iparr: ipStr}, function (res) {
                                    });

                                    var y = setInterval(function () {
                                        $.post("/getGateApi", {}, function (result) {
                                            if (result.code == 200) {
                                                if (result.data && result.data != "null") {
                                                    if (result.data.indexOf("complete") != -1 && result.data.indexOf("download") != -1) {
                                                        $(".process-title").html("").html("所有程序已设置完成，正在重启机器");
                                                    } else if (result.data.indexOf("download") != -1) {
                                                        $(".process-title").html("").html("正在下载监控程序，并设置开机启动");
                                                    }

                                                    var data = JSON.parse(result.data);

                                                    if (!data.length) {
                                                        clearInterval(y);

                                                        var nh = setInterval(function () {
                                                            $.post("/requestNewHost", {}, function (res) {
                                                                if (res.code == "200") {
                                                                    clearInterval(inter);
                                                                    clearInterval(nh);

                                                                    $("#loading_bar").css("width", "100%");
                                                                    $(".layui-progress-text").html("100%");

                                                                    layer.close(index);
                                                                    that.getList(that.page);
                                                                }
                                                            });
                                                        }, 1000);
                                                    }
                                                }
                                            }

                                        })
                                    }, 1000);
                                }
                            });
                        } else {
                            layer.close(index);
                            clearInterval(inter);
                        }
                    });
                } else {
                    layer.alert("请先设置机器密码！");
                }
            });
        });

        //查看详情
        $(document).on("click", ".opera-play", function () {
            var macAddress = $(this).data("id");
            var cpuCores = $(this).attr('core');
            var disk = $(this).attr("disk");
            var wakeOn = $(this).attr("wakeon");
            var ip = $(this).attr("ip");
            window.location.href = "/deviceDetail?id=" + macAddress + "&ip=" + ip + "&wakeOn=" + wakeOn + "&core=" + cpuCores + "&disk=" + disk;
        });

        //硬盘查看详细
        $(document).on("click", ".disk-view", function () {
            var macAddr = $(this).attr("mac");
            var diskTotal = $(this).data("disk") || [];
            var diskName = $(this).data("diskname") || [];

            $.post("/getDiskUsage", {macAddr: macAddr}, function (res) {
                if (res.code == "200") {
                    var diskUsed = JSON.parse(res.data) || [];

                    if (!diskTotal.length || !diskUsed.length) return layer.msg("暂无数据");

                    for (var j = 0; j < diskTotal.length; j++) {
                        diskTotal[j] = util.getUnit(diskTotal[j]);
                    }
                    for (var jj = 0; jj < diskUsed.length; jj++) {
                        diskUsed[jj] = util.getUnit(diskUsed[jj]);
                    }
                    for (var jjj = 0; jjj < diskName.length; jjj++) {
                        var arr = diskName[jjj].split("/");
                        diskName[jjj] = arr[arr.length - 1];
                    }

                    var ejs = new EJS({text: $('#disk_temp').html(), type: '['});
                    var html = ejs.render({
                        dataU: diskUsed,
                        dataT: diskTotal,
                        dataN: diskName
                    });

                    layer.open({
                        title: '矿机磁盘信息 (已用/总量)',
                        content: html,
                        resize: false,
                        area: ['500px', "auto"]
                    })
                } else {
                    layer.msg(res.msg)
                }
            });
        });

        //编辑
        $(document).on("click", ".opera-down", function () {
            var macAddress = $(this).data("id");
            var machineName = $(this).attr("machinename");

            if (!macAddress) return layer.msg("缺少矿机Mac地址");

            layer.open({
                title: '矿机信息',
                content: $("#edit_machine_temp").html(),
                resize: false,
                area: ['500px', "500px"],
                btn: ['提交', '取消'],
                success: function () {
                    $("#machineName").val(machineName);
                },
                yes: function () {
                    var machineName = $("#machineName").val().trim();

                    if (!machineName) return layer.alert("缺少参数");

                    $.ajax({
                        url: "/editMachineApi",
                        data: {
                            macAddress: macAddress,
                            machineName: machineName,
                            mineType: JSON.stringify([]),
                            ip: ""
                        },
                        dataType: 'json',
                        type: 'post',
                        success: function (res) {
                            layer.msg(res.msg);
                            setTimeout(function () {
                                that.getList(that.page);
                            }, 1000);
                        },
                        error: function () {
                            layer.msg('服务器异常，请联系管理员', {time: 1000, icon: 0});
                        }
                    })
                },
                btn2: function () {
                    layer.close();
                }
            });
        });

        $(document).on("change", ".miner-item-check", function () {
            var miner = $(this).attr("value");
            if ($(this).prop("checked") && miner) {
                that.minerTypeArr.push(miner);
            } else {
                $('#cur-page-all').prop('checked', false);
                that.minerTypeArr.splice(that.minerTypeArr.indexOf(miner), 1);
            }
            console.log(that.minerTypeArr)
        });

        //删除
        $(document).on("click", ".opera-delete", function () {
            var macAddress = $(this).data("id");
            var ip = $(this).data("ip");

            layer.confirm(`确定要删除此机器吗？`, function () {
                layer.close()
                var index = layer.load(2);

                $.ajax({
                    url: "/removeMachineApi",
                    type: "post",
                    dataType: "json",
                    data: {
                        macAddress: macAddress,
                        ip: ip
                    },
                    success: function (res) {
                        layer.close(index);
                        layer.msg(res.msg)
                        if (res.code == "200") {
                            setTimeout(function () {
                                that.getList(that.page);
                            }, 1000);
                        }
                    }, error: function () {
                        layer.close(index);
                        layer.msg('服务器异常，请联系管理员', {time: 1000, icon: 0});
                    }
                });
            });
        });
    },

    getList: function (page) {
        var that = this;
        $.ajax({
            url: "/deviceListApi",
            data: {
                page: page || 1,
                limit: 10
            },
            dataType: 'json',
            type: 'post',
            success: function (res) {
                if (res.code == 200) {
                    var list = JSON.parse(res.data);
                    var pages = JSON.parse(res.pages);
                    var totalRow = pages.TotalRow;
                    var pageSize = pages.PageSize;
                    var pageIndex = pages.PageIndex;

                    if (!list || list.length == 0) {
                        $("#logs_pos").html("暂无数据");
                        return false;
                    }

                    for (var i of list) {
                        i.MinerName = JSON.parse(i.MinerName);
                    }

                    var temp = $('#list_temp').html();
                    var ejs = new EJS({text: temp, type: '['});
                    var html = ejs.render({data: list, pages: pages});
                    $("#logs_pos").html(html);

                    if (totalRow / pageSize <= 1) {
                        $("#listPagination").hide();
                    } else {
                        $("#listPagination").show();
                    }
                    util.pageInit($("#listPagination"), pageIndex, pageSize, totalRow, deviceListObj);
                } else {
                    layer.msg(res.msg, {time: 1000, icon: 0});
                }
            },
            error: function () {
                layer.msg('服务器异常，请联系管理员', {time: 1000, icon: 0});
            }
        });

    }
};