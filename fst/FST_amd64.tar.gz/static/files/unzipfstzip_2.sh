#!/bin/bash
Platform=`uname -a| grep Ubuntu`
echo ">>>>>>>>>>>>>>>"
if [[ -n "$Platform" ]];then
    if [[ -z `which curl` ]]; then
        apt update -y
        apt install curl -y
    fi
	if ! command -v unzip > /dev/null;then
    	apt update -y
    	apt install unzip -y
    fi
else
    if [[ -z `which lsof` ]]; then
    	    yum install -y lsof
    fi
	if ! command -v unzip > /dev/null;then
	    yum install -y unzip zip
	fi
fi

Arch=`uname -m | grep -i x86`
if [[ -n "$Arch" ]]; then
    unzip -o filestorm_amd64.zip
    mv filestorm_amd64 filestorm
    rm filestorm_amd64.zip

    cd filestorm/

    touch storm.out
    chmod 664 storm.out

    chmod 0755 ipfs
    cp -f ipfs /bin/

    ver=`ipfs version`
    if [[ -z "$ver" ]]; then
        echo "Ipfs installed failed."
        exit 0
    fi

    kill -9 $(lsof -i:9527 | awk 'NR!=1 {print $2}')

    chmod 0755 stormcatcher-linux-amd64
    nohup ./stormcatcher-linux-amd64 >storm.out 2>&1 &
else
    unzip -o filestorm_arm64.zip
    mv filestorm_arm64 filestorm
    rm filestorm_arm64.zip

    cd filestorm/

    touch storm.out
    chmod 664 storm.out

    chmod 0755 ipfs
    cp -f ipfs /bin/

    ver=`ipfs version`
    if [[ -z "$ver" ]]; then
        echo "Ipfs installed failed."
        exit 0
    fi

    kill -9 $(lsof -i:9527 | awk 'NR!=1 {print $2}')

    chmod 0755 stormcatcher-linux-arm64
    nohup ./stormcatcher-linux-arm64 >storm.out 2>&1 &
fi

exit 0