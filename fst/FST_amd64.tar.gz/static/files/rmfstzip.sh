#!/bin/bash
#cd /home
rm filestorm_amd64.zip
rm -rf filestorm