#!/bin/bash

if [[ ! -d ./filestorm ]]; then
    exit 0
fi

cd filestorm
Arch=`uname -m | grep -i x86`
touch storm.out
chmod 664 storm.out
if [[ -n "$Arch" ]]; then
    nohup ./stormcatcher-linux-amd64 >storm.out 2>&1 &
else
    nohup ./stormcatcher-linux-arm64 >storm.out 2>&1 &
fi

exit 0