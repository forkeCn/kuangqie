var selectDisk = "";
var selectSize = "";
var selectMount = "";
var updateLink = "";

function alertTips(tips) {
    layer.alert(tips);
}

var downLoadingTimer = null;

var services = [];
var disks = [];
var reg = /\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/;
var _ip = reg.exec(window.location.href)[0];

function getFSInstallState() {
    $.ajax({
        url: "/FileStormInstallState",
        type: "post",
        dataType: "json",
        data: {},
        success: function (res) {
            if (res.code == 200) {
                if (res.data == "1") {
                    $("#download").hide();
                    $("#start").show();
                } else if (res.data == "2") {
                    $("#download").html("filestorm运行中").off("click");
                }
            }
        }
    });
}

//下载进度
function downloading() {
    $.ajax({
        url: "/Downloading",
        type: "post",
        dataType: "json",
        data: {},
        success: function (res) {
            if (res.code == 200) {
                if (res.data < 100) {
                    $("#download").html(res.data + "%");
                    downLoadingTimer = setTimeout(downloading, 1000);
                }
                else {
                    $("#download").html("下载filestorm");
                    alertTips("下载完成");
                    setTimeout(function () {
                        window.location.reload();
                    }, 800);
                }
            }
        }
    });
}

//下载进度
function updating() {
    $.ajax({
        url: "/Downloading",
        type: "post",
        dataType: "json",
        data: {},
        success: function (res) {
            if (res.code == 200) {
                if (res.data < 100) {
                    $("#versionUpdate").html("已下载" + res.data + "%");
                    downLoadingTimer = setTimeout(updating, 1000);
                }
                else {
                    setTimeout(function () {
                        window.location.reload();
                    }, 1000);
                }
            }
        }
    });
}


function initUI() {
    $.ajax({
        url: "/InitUI",
        type: "post",
        dataType: "json",
        data: {},
        success: function (res) {
            services = JSON.parse(res.data)
            console.log(services);
            var tpl = $("#processListTpl").html();
            var styles = ["list-group-item-success", "list-group-item-info", "list-group-item-warning", "list-group-item-danger"];
            var str = "";
            for (var i = 0; i < services.length; i++) {
                str += tpl.replace(/{style}/g, styles[i % 4])
                    .replace(/{disk}/g, services[i].DriveName)
                    .replace(/{size}/g, getUnit(services[i].Size || 0))
                    .replace(/{pid}/g, services[i].PID)
                    .replace(/{port}/g, services[i].Port.join())
                    .replace(/{status}/g, services[i].Status)
                    .replace(/{mount}/g, services[i].MountPoint)
                    .replace(/{port}/g, services[i].Port)
            }
            $("#processList").html(str);
            for (var i = 0; i < services.length; i++) {
                if (services[i].Status) {
                    $(".badgeUpnp").eq(i).html("upnp已开启").addClass("opened");
                }
            }
        }
    });
}

function showDiskList() {
    var tpl = $("#diskListTpl").html();
    var str = "";
    for (var i = 0; i < disks.length; i++) {
        str += tpl.replace(/{disk}/g, disks[i].name)
            .replace(/{avail}/g, getUnit(disks[i].avail || 0))
            .replace(/{size}/g, getUnit(disks[i].total || 0))
            .replace(/{mount}/g, disks[i].mount)
    }
    return str
}

// 单位换算，默认kb
function getUnit(intNumber) {
    intNumber = parseInt(intNumber);
    var units = ["KB", "MB", "GB", "TB", "PB"];
    var obj = {
        MB: 1024,
        GB: 1024 * 1024,
        TB: 1024 * 1024 * 1024,
        PB: 1024 * 1024 * 1024 * 1024,
        // PB: 1024 * 1024 * 1024 * 1024 * 1024
    };

    for (var i = 0; i < units.length; i++) {
        if (Math.floor(intNumber / obj[units[i]]) < 1000) {
            return (intNumber / obj[units[i]]).toFixed(2) + units[i];
        }
    }
}