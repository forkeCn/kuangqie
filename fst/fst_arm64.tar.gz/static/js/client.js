$(function () {

    getFSInstallState();
    initUI();

    //下载
    $("#download").click(function () {
        $.ajax({
            url: "/Download",
            type: "post",
            dataType: "json",
            data: {},
            success: function (res) {
                if (res.code == 200) {
                    alertTips("开始下载,请不要关闭窗口！！！");
                    downLoadingTimer = setTimeout(downloading, 1000);
                }
            }
        });
    });

    //启动filestorm
    $("#start").on("click", function () {
        $.ajax({
            url: "/Start",
            type: "post",
            dataType: "json",
            data: {},
            success: function (res) {
                if (res.code == 200) {
                    alertTips("启动成功！");
                    $("#start").html("filestorm运行中").off("click");
                }
            }
        });
    });

    //选择硬盘弹窗, 添加 并 注册
    $("#add").click(function () {
        $.ajax({
            url: "/GetDisks",
            type: "post",
            dataType: "json",
            data: {},
            success: function (res) {
                var name = JSON.parse(res.name) || [];
                var total = JSON.parse(res.total) || [];
                var use = JSON.parse(res.use) || [];
                var mount = JSON.parse(res.mount) || [];
                var t = null;
                var flagNew = true;
                disks = [];
                for (var i = 0; i < total.length; i++) {
                    flagNew = true;
                    //先判断磁盘是否已经运行了程序
                    for (var j = 0; j < services.length; j++) {
                        if (services[j].DriveName == name[i]) {
                            flagNew = false;
                            break;
                        }
                    }
                    //去除已运行程序的磁盘
                    if (flagNew) {
                        t = {};
                        t.name = name[i];
                        t.total = total[i];
                        t.avail = total[i] - use[i];
                        t.mount = mount[i]
                        disks.push(t);
                    }
                }

                if (!disks.length) return layer.msg("暂无可用磁盘");

                layer.open({
                    title: '选择硬盘',
                    content: showDiskList(),
                    resize: false,
                    area: ['400px', "300px"],
                    btn: ["确定", "取消"],
                    yes: function () {
                        var idx = layer.load(2);
                        $.ajax({
                            url: "/Register",
                            type: "post",
                            dataType: "json",
                            data: {
                                devicePath: selectDisk,
                                size: selectSize,
                                mount: selectMount
                            },
                            success: function (res) {
                                layer.close(idx);
                                if (res.code == "200") {
                                    var data = JSON.parse(res.data);
                                    var mess = res.msg + "，4001，5001，8080端口分别映射为: " + data["4001"] + "，" + data["5001"] + "，" + data["8080"];

                                    layer.msg(mess);
                                    setTimeout(function () {
                                        window.location.reload();
                                    }, 800);
                                } else layer.msg(res.msg);
                            }
                        })
                    }
                });
            }
        });
    });

    //查看日志
    $(document).on("click", "#readlog", function () {
        window.location.href = "/ShowLog";
    });

    //选择硬盘列表
    $(document).on("click", ".diskItem", function () {
        $(".diskItem").removeClass("ac");
        $(this).addClass("ac");
        selectDisk = $(this).attr("disk");
        selectSize = $(this).attr("size");
        selectMount = $(this).attr("mount");
    });

    //停止进程
    $(document).on("click", ".badgeStop", function () {
        var devPath = $(this).attr("disk");

        layer.confirm("确定要停止吗？", function () {
            if (!devPath) return layer.msg("缺少参数");
            $.ajax({
                url: "/StopFST",
                type: "post",
                dataType: "json",
                data: {
                    devicePath: devPath
                },
                success: function (res) {
                    layer.msg(res.msg);
                    setTimeout(function () {
                        window.location.reload();
                    }, 1000);
                }
            });
        }, function () {
            layer.closeAll();
        });
    });
    //开启upnp
    $(document).on("click", ".badgeUpnp", function () {
        var status = $(this).attr("status");

        if (status == "true") return layer.msg("upnp已开启");

        var registerId = $(this).attr("pid");
        var devPath = $(this).attr("disk");
        var port = $(this).attr("port");
        port = port.split(",");

        var idx = layer.load(2);
        $.ajax({
            url: "/OpenUpnp",
            type: "post",
            dataType: "json",
            data: {
                pid: registerId,
                devicePath: devPath,
                p_4001: port[0],
                p_5001: port[1],
                p_8080: port[2]
            },
            success: function (res) {
                layer.close(idx);
                layer.msg(res.msg);
                if (res.code == "200") setTimeout(function () {
                    $(".badgeUpnp").addClass("opened");
                    window.location.reload();
                }, 800);
            }
        });
    });
    //进程详情
    $(document).on("click", ".badgeDetail", function () {
        var devPath = $(this).attr("disk");
        var mount = $(this).attr("mount");
        $.ajax({
            url: "http://" + _ip + ":9527/getRegisterIdByDevicePath",
            type: "get",
            dataType: "text",
            data: {
                devicePath: devPath
            },
            success: function (res) {
                if (res.indexOf("fail") != -1) return alert(res);

                $.ajax({
                    url: "/FileStormInfo",
                    type: "post",
                    dataType: "json",
                    data: {
                        devicePath: devPath,
                        mount: mount
                    },
                    success: function (resp) {
                        if (resp.code == 200) {
                            var ipfs = resp.ipfs;
                            var stm = resp.stm;

                            layer.open({
                                title: 'fileStorm进程明细',
                                content: $("#fileStormInfoTpl").html(),
                                resize: false,
                                area: ['700px', "400px"],
                                success: function () {
                                    $("#info_title").append("（" + devPath + "）");
                                    $("#registerId").html("").html(res);
                                    $("#ipfs").html("").html(ipfs == "1" ? "运行中" : "未运行");
                                    $("#storm").html("").html(stm == "1" ? "运行中" : "未运行");
                                }
                            });
                        }
                    }
                })
            }
        })
    });

    //打开页面就去检测版本更新
    $.ajax({
        url: "http://" + _ip + ":9527/getVersionLink",
        type: "post",
        dataType: 'text',
        data: {},
        success: function (res) {
            // res = "http://filestorm-forke.oss-cn-hangzhou.aliyuncs.com/filestorm.zip"
            if (res.length > 0) {
                updateLink = res;
                $("#versionNewest").hide();
                $("#versionUpdate").show();
            } else {
                $("#versionNewest").show();
                $("#versionUpdate").hide();
            }
        },
        error: function () {
            $("#versionCode").html("未检测到新版本").show();
            $("#versionNewest").hide();
            $("#versionUpdate").hide();
        }
    });

    //点击升级
    $("#versionUpdate").click(function () {
        //有新版本 升级
        if (!updateLink) return;
        $.ajax({
            url: "/UpdateFST",
            type: "post",
            dataType: "json",
            data: {
                link: updateLink
                // link: "http://filestorm-forke.oss-cn-hangzhou.aliyuncs.com/"
            },
            success: function (res) {
                alertTips("开始下载,请不要关闭窗口！！！");
                downLoadingTimer = setTimeout(updating, 1000);
            }
        });
    });
});