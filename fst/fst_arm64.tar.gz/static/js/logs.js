$(function () {

    //计算最大高度；
    var wH = $(window).height();
    var maxH = wH - 260;
    $("#logsPanel").css("max-height", maxH + "px")
        .css("height", maxH + "px");

    $("#getLogBtn").click(function () {
        var line = 50;
        var lineStr = $("#logsLine").val();
        if (lineStr) {
            line = parseInt(lineStr, 10);
        }
        if (isNaN(line)) {
            layer.alert("请输入正确数值")
        }
        else {
            $.ajax({
                url: "/GetLogs",
                type: "post",
                dataType: "json",
                data: {
                    line: line
                },
                success: function (res) {
                    if (res.code == 200) {
                        $("#logsPanel").html(res.data);
                    } else {
                        $("#logsPanel").html("暂无内容");
                    }
                }
            });
        }
    });
});