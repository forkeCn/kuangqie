#!/bin/bash

Arch=`uname -m | grep -i x86`
if [[ -n "$Arch" ]]; then
    kill -9 $(pidof stormcatcher-linux-amd64)
    rm filestorm/stormcatcher-linux-amd64

    unzip -o filestorm_amd64.zip "filestorm_amd64/stormcatcher-linux-amd64"
    cp filestorm_amd64/stormcatcher-linux-amd64 filestorm/
    rm -rf filestorm_amd64/

    cd filestorm/
    chmod 0755 stormcatcher-linux-amd64
    touch storm.out
    chmod 664 storm.out

    nohup ./stormcatcher-linux-amd64 >storm.out 2>&1 &
else
    kill -9 $(pidof stormcatcher-linux-arm64)
    rm filestorm/stormcatcher-linux-arm64

    unzip -o filestorm_arm64.zip "filestorm_arm64/stormcatcher-linux-arm64"
    cp filestorm_arm64/stormcatcher-linux-arm64 filestorm/
    rm -rf filestorm_arm64/

    cd filestorm/
    chmod 0755 stormcatcher-linux-arm64
    touch storm.out
    chmod 664 storm.out

    nohup ./stormcatcher-linux-arm64 >storm.out 2>&1 &
fi

exit 0