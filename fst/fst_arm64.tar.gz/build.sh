CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go build -ldflags "-s -w"  main.go
if [ -n `which upx` ]; then
  upx -9 main
fi
